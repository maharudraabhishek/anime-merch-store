import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '../context/CartContext.jsx';
import { createOrder } from '../api/index.js';

/**
 * Checkout page.  Displays a summary of the cart and allows the
 * customer to place an order.  On successful submission the cart
 * is cleared and the user is redirected to the orders page.
 */
const Checkout = () => {
  const { cart, total, clearCart } = useContext(CartContext);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleOrder = async () => {
    setError('');
    setLoading(true);
    try {
      // Send the current cart and total to the backend.  We include a date
      // to record when the order was placed.
      await createOrder({ items: cart, total, date: new Date().toISOString() });
      clearCart();
      navigate('/orders');
    } catch (err) {
      console.error(err);
      setError('Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-xl mx-auto mt-8 text-center">
        <h2 className="text-2xl font-semibold mb-4">Checkout</h2>
        <p>Your cart is empty.</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto mt-8">
      <h2 className="text-2xl font-semibold mb-4">Checkout</h2>
      <ul className="space-y-4">
        {cart.map((item) => (
          <li key={item.id} className="flex justify-between items-center border rounded p-3 bg-card text-foreground">
            <span>{item.quantity} × {item.title}</span>
            <span>₹{(item.price * item.quantity).toFixed(2)}</span>
          </li>
        ))}
      </ul>
      <div className="mt-4 text-right font-semibold text-lg">
        Total: ₹{total.toFixed(2)}
      </div>
      {error && <p className="text-red-500 mt-2 text-sm">{error}</p>}
      <button
        onClick={handleOrder}
        disabled={loading}
        className="mt-6 w-full bg-primary text-white py-2 rounded hover:bg-primary/80 disabled:opacity-50"
      >
        {loading ? 'Placing Order...' : 'Place Order'}
      </button>
    </div>
  );
};

export default Checkout;
