import React from 'react'
import { HERO_SLIDES } from '../lib/pinImages.js'

const slug = (s) => String(s || 'img').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

export default function Carousel() {
  const slides = HERO_SLIDES.map((s, i) => ({
    id: s.id ?? i+1,
    title: s.title,
    // resolve to local asset the fetch script will download
    src: `/assets/${slug(s.title)}.jpg`
  }));

  return (
    <div className="rounded-lg overflow-hidden border">
      <div className="grid md:grid-cols-3 gap-0">
        {slides.map(s => (
          <div key={s.id} className="h-56 md:h-64 overflow-hidden">
            <img src={s.src} alt={s.title} className="w-full h-full object-cover" loading="eager" />
          </div>
        ))}
      </div>
    </div>
  )
}