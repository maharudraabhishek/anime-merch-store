import React, { createContext, useState } from 'react'
import { loginUser } from '../api/index.js'

export const AuthContext = createContext({
  user: null,
  login: async () => {},
  logout: () => {}
})

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)

  const login = async (credentials) => {
    const data = await loginUser(credentials)
    setUser({ username: data.user?.username, email: data.user?.email })
  }

  const logout = () => setUser(null)

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}