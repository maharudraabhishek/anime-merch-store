// Downloads PIN_MAP and HERO_SLIDES images to /public/assets as local files.
// This runs during Docker build or CI: `npm run fetch:assets`

import fs from 'node:fs';
import path from 'node:path';
import https from 'node:https';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { PIN_MAP, HERO_SLIDES } from '../src/lib/pinImages.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const outDir = path.join(__dirname, '..', 'public', 'assets');
fs.mkdirSync(outDir, { recursive: true });

const slug = (s) => String(s || 'img')
  .toLowerCase()
  .replace(/[^a-z0-9]+/g, '-')
  .replace(/(^-|-$)/g, '');

function download(url, dest) {
  const proto = url.startsWith('https') ? https : http;
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    const req = proto.get(url, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        // follow redirects
        return download(res.headers.location, dest).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        file.close(); fs.unlink(dest, ()=>{});
        return reject(new Error(`HTTP ${res.statusCode} for ${url}`));
      }
      res.pipe(file);
      file.on('finish', () => file.close(resolve));
    });
    req.on('error', (err) => {
      file.close(); fs.unlink(dest, ()=>{});
      reject(err);
    });
  });
}

const tasks = [];

// Product images
PIN_MAP.forEach((entry, idx) => {
  const base = slug(entry.keys[0] || `pin-${idx}`);
  const fname = `${base}.jpg`; // normalize to .jpg
  const dest = path.join(outDir, fname);
  tasks.push(
    download(entry.url, dest).catch((e) => {
      console.warn('Failed to download', entry.url, e.message);
    })
  );
});

// Hero banners
HERO_SLIDES.forEach((slide, idx) => {
  const base = slug(slide.title || `hero-${idx+1}`);
  const fname = `${base}.jpg`;
  const dest = path.join(outDir, fname);
  tasks.push(
    download(slide.src, dest).catch((e) => {
      console.warn('Failed to download', slide.src, e.message);
    })
  );
});

Promise.all(tasks).then(() => {
  console.log('Assets fetched to /public/assets');
}).catch((e) => {
  console.error('Asset fetch error:', e);
  process.exit(0); // don't fail build if a few images fail
});