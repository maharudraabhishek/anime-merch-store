import React, { createContext, useMemo, useState } from 'react'

export const CartContext = createContext({
  cart: [], addToCart: () => {}, removeFromCart: () => {}, updateQty: () => {}, clearCart: () => {}, total: 0
})

export function CartProvider({ children }) {
  const [cart, setCart] = useState([])

  const addToCart = (product, qty = 1) => {
    if (!product?.id) return
    setCart(prev => {
      const i = prev.findIndex(x => x.id === product.id)
      if (i === -1) return [...prev, { ...product, qty }]
      const next = [...prev]; next[i] = { ...next[i], qty: next[i].qty + qty }
      return next
    })
  }

  const removeFromCart = (id) => setCart(prev => prev.filter(x => x.id !== id))
  const updateQty = (id, qty) => setCart(prev => prev.map(x => x.id === id ? { ...x, qty: Math.max(1, qty) } : x))
  const clearCart = () => setCart([])
  const total = useMemo(() => cart.reduce((s,i)=> s + Number(i.price||0)*Number(i.qty||1), 0), [cart])

  return <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQty, clearCart, total }}>{children}</CartContext.Provider>
}