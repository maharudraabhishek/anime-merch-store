import React, { useEffect, useState } from 'react'
import Carousel from '../components/Carousel.jsx'
import { fetchProducts } from '../api/index.js'
import ProductCard from '../components/ProductCard.jsx'

export default function Home() {
  const [products, setProducts] = useState([])
  useEffect(() => { fetchProducts().then(setProducts).catch(console.error) }, [])
  return (
    <div className="space-y-6">
      <Carousel />
      <section>
        <h2 className="text-xl font-semibold mb-3">Bestsellers</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </div>
  )
}