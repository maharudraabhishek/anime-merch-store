import React, { useContext } from 'react';
import { CartContext } from '../context/CartContext.jsx';
import { Link } from 'react-router-dom';

/**
 * Shopping cart page.  Displays the contents of the cart from
 * CartContext.  Users can remove items and proceed to checkout.  The
 * total cost is displayed at the bottom.  If the cart is empty a
 * message is shown.
 */
const Cart = () => {
  const { cart, removeFromCart, total } = useContext(CartContext);
  return (
    <div className="max-w-3xl mx-auto mt-8">
      <h2 className="text-2xl font-semibold mb-4">Your Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          <ul className="space-y-4">
            {cart.map((item) => (
              <li
                key={item.id}
                className="flex items-center justify-between border rounded p-4 bg-card text-foreground shadow"
              >
                <div className="flex items-center space-x-4">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div>
                    <p className="font-semibold">{item.title}</p>
                    <p className="text-sm">Qty: {item.quantity}</p>
                    <p className="text-sm text-secondary">₹{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
                <button
                  onClick={() => removeFromCart(item.id)}
                  className="text-red-500 hover:underline"
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>
          <div className="mt-6 text-right">
            <p className="text-lg font-semibold mb-2">Total: ₹{total.toFixed(2)}</p>
            <Link
              to="/checkout"
              className="inline-block bg-primary text-white px-4 py-2 rounded hover:bg-primary/80"
            >
              Proceed to Checkout
            </Link>
          </div>
        </>
      )}
    </div>
  );
};

export default Cart;
