import React, { useEffect, useState, useContext } from 'react';
import { fetchOrders } from '../api/index.js';
import { AuthContext } from '../context/AuthContext.jsx';

export default function Orders() {
  const { user } = useContext(AuthContext)
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const u = user?.username || localStorage.getItem('guestUser') || ''
    if (!u) { setOrders([]); setLoading(false); return }
    fetchOrders(u).then(setOrders).finally(()=> setLoading(false))
  }, [user])

  if (loading) return <div>Loading orders…</div>
  if (!orders.length) return <div>No orders yet.</div>

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Your Orders</h1>
      <div className="space-y-4">
        {orders.map(o => (
          <div key={o.id} className="border rounded-md p-3">
            <div className="flex items-center justify-between">
              <div className="font-medium">Order #{o.id}</div>
              <div className="text-sm opacity-70">{new Date(o.createdAt).toLocaleString()}</div>
            </div>
            <ul className="list-disc ml-6 mt-2">
              {o.items.map((it, idx) => <li key={idx}>{it.title} × {it.qty} — ₹{it.price * it.qty}</li>)}
            </ul>
            <div className="text-right font-medium mt-2">Total: ₹{o.total}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
