import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CartContext } from '../context/CartContext.jsx'
import { AuthContext } from '../context/AuthContext.jsx'
import { createOrder } from '../api/index.js'

export default function Checkout() {
  const { cart, total, clearCart } = useContext(CartContext)
  const { user } = useContext(AuthContext)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const navigate = useNavigate()

  if (!cart.length) return <div>No items in cart.</div>

  const placeOrder = async () => {
    setSubmitting(true)
    setError(null)
    try {
      const payload = {
        items: cart.map(({ id, title, price, qty }) => ({ id, title, price, qty })),
        total,
        username: user?.username || null
      }

      const res = await createOrder(payload)

      if (!user?.username && res?.user?.username) {
        localStorage.setItem('guestUser', res.user.username)
      }


      clearCart()
      navigate('/orders?success=1')
    } catch (e) {
      setError(e?.response?.data?.error || 'Failed to place order')
      
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Checkout</h1>

      <div className="border rounded-md p-3 mb-4">
        {cart.map((i) => (
          <div key={i.id} className="flex justify-between py-1">
            <div>{i.title} × {i.qty}</div>
            <div>₹{Number(i.price) * Number(i.qty)}</div>
          </div>
        ))}
        <div className="border-t mt-2 pt-2 flex justify-between font-medium">
          <div>Total</div>
          <div>₹{total}</div>
        </div>
      </div>

      {error && <div className="mb-3 text-red-600">{error}</div>}

      <button
        disabled={submitting}
        onClick={placeOrder}
        className="rounded px-4 py-2 bg-black text-white disabled:opacity-50"
      >
        {submitting ? 'Placing…' : 'Place order'}
      </button>
    </div>
  )
}
