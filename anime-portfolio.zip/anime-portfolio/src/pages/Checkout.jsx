import React, { useContext, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartContext } from './context/CartContext.jsx';
import { AuthContext } from './context/AuthContext.jsx';
import { createOrder } from './api/index.js';
import { useToast } from './context/ToastContext.jsx';

const inr = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' });

export default function Checkout() {
  const { cart, total, clearCart } = useContext(CartContext);
  const { user } = useContext(AuthContext);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const { notify } = useToast();

  // Guard for empty/undefined cart
  if ((cart?.length ?? 0) === 0) return <div>No items in cart.</div>;

  const placeOrder = async () => {
    setSubmitting(true);
    setError(null);

    try {
      // Normalize quantity: support both `qty` and `quantity`
      const items = cart.map(({ id, title, price, qty, quantity }) => ({
        id,
        title,
        price,
        qty: qty ?? quantity ?? 1
      }));

      const payload = {
        items,
        total, // assume your backend recalculates / validates
        username: user?.username || null
      };

      const res = await createOrder(payload);

      // If server created a guest user, remember it for order history page
      if (!user?.username && res?.user?.username) {
        localStorage.setItem('guestUser', res.user.username);
      }

      notify(
        res?.orderId
          ? `Order #${res.orderId} placed successfully`
          : 'Order placed successfully',
        { type: 'success' }
      );

      clearCart();

      // Prefer navigating with orderId if available
      if (res?.orderId) {
        navigate(`/orders/${res.orderId}`);
      } else {
        navigate('/orders?success=1');
      }
    } catch (e) {
      setError(e?.response?.data?.error || 'Failed to place order');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Checkout</h1>

      <div className="border rounded-md p-3 mb-4">
        {cart.map((i) => {
          const qty = i.qty ?? i.quantity ?? 1;
          const lineTotal = Number(i.price) * Number(qty);
          return (
            <div key={i.id} className="flex justify-between py-1">
              <div>{i.title} × {qty}</div>
              <div>{inr.format(lineTotal)}</div>
            </div>
          );
        })}
        <div className="border-t mt-2 pt-2 flex justify-between font-medium">
          <div>Total</div>
          <div>{inr.format(Number(total))}</div>
        </div>
      </div>

      {error && <div className="mb-3 text-red-600">{error}</div>}

      <button
        disabled={submitting}
        onClick={placeOrder}
        className="rounded px-4 py-2 bg-black text-white disabled:opacity-50"
      >
        {submitting ? 'Placing…' : 'Place order'}
      </button>
    </div>
  );
}
