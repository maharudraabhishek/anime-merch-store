// src/context/ToastContext.jsx
import React, {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
} from 'react'

const ToastContext = createContext({
  toasts: [],
  notify: () => {},
  remove: () => {},
  clear: () => {},
})

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]) // [{ id, msg, type }]
  const idRef = useRef(0)

  const remove = useCallback((id) => {
    setToasts((ts) => ts.filter((t) => t.id !== id))
  }, [])

  const clear = useCallback(() => setToasts([]), [])

  const notify = useCallback((msg, opts = {}) => {
    const id = ++idRef.current
    const type = opts.type || 'info' // 'success' | 'error' | 'info'
    const ttl = opts.ttl ?? 3000

    setToasts((ts) => [...ts, { id, msg, type }])
    // auto-dismiss
    if (ttl > 0) {
      setTimeout(() => remove(id), ttl)
    }
  }, [remove])

  const value = useMemo(
    () => ({ toasts, notify, remove, clear }),
    [toasts, notify, remove, clear]
  )

  return <ToastContext.Provider value={value}>{children}</ToastContext.Provider>
}

export function useToast() {
  return useContext(ToastContext)
}
