import React from "react";

const CartContext = React.createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = React.useState(() => {
    try {
      const raw = localStorage.getItem("cart:v1");
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  React.useEffect(() => {
    localStorage.setItem("cart:v1", JSON.stringify(items));
  }, [items]);

  const getQty = React.useCallback((id) => items[id]?.qty ?? 0, [items]);

  const increment = React.useCallback((product, step = 1) => {
    let firstAdd = false;
    setItems((prev) => {
      const curr = prev[product.id]?.qty ?? 0;
      const nextQty = curr + step;
      const next = { ...prev };
      if (nextQty <= 0) {
        delete next[product.id];
      } else {
        if (curr === 0 && nextQty > 0) firstAdd = true;
        next[product.id] = {
          id: product.id,
          title: product.title ?? product.name ?? "Product",
          price: product.price ?? 0,
          image: product.image,
          qty: nextQty,
        };
      }
      return next;
    });
    return { firstAdd };
  }, []);

  const decrement = React.useCallback((id, step = 1) => {
    setItems((prev) => {
      const curr = prev[id]?.qty ?? 0;
      const nextQty = curr - step;
      const next = { ...prev };
      if (nextQty <= 0) delete next[id];
      else next[id] = { ...next[id], qty: nextQty };
      return next;
    });
  }, []);

  const totalCount = React.useMemo(
    () => Object.values(items).reduce((n, it) => n + it.qty, 0),
    [items]
  );

  const value = React.useMemo(
    () => ({ items, getQty, increment, decrement, totalCount }),
    [items, getQty, increment, decrement, totalCount]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = React.useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within <CartProvider>");
  return ctx;
}
