// src/components/Toaster.jsx
import React, { useEffect } from 'react'
import { createPortal } from 'react-dom'
import { useToast } from '../context/ToastContext.jsx'

export default function Toaster() {
  const { toasts, remove } = useToast()

  // Ensure a host div exists for the portal
  useEffect(() => {
    let host = document.getElementById('toast-root')
    if (!host) {
      host = document.createElement('div')
      host.id = 'toast-root'
      document.body.appendChild(host)
    }
    return () => {
      // keep it around across route transitions; remove if you prefer
    }
  }, [])

  const host = typeof document !== 'undefined' ? document.getElementById('toast-root') : null
  if (!host) return null

  return createPortal(
    <>
      {/* Scoped styles */}
      <style>{`
        @keyframes toast-in {
          from { transform: translateY(8px); opacity: 0 }
          to   { transform: translateY(0);   opacity: 1 }
        }
        @keyframes toast-out {
          from { transform: translateY(0);   opacity: 1 }
          to   { transform: translateY(8px); opacity: 0 }
        }
        .toaster-host {
          position: fixed;
          right: 16px;
          bottom: 16px;
          display: flex;
          flex-direction: column;
          gap: 10px;
          z-index: 9999;
          pointer-events: none; /* clicks pass through gaps */
        }
        .toast {
          pointer-events: auto;
          display: flex; align-items: center; gap: 10px;
          max-width: 360px;
          padding: 10px 12px;
          border-radius: 12px;
          box-shadow: 0 10px 25px rgba(0,0,0,.18);
          color: #fff;
          background: #111; /* default */
          animation: toast-in .16s ease-out;
        }
        .toast[data-type="success"] { background: #0c7c45; }
        .toast[data-type="error"]   { background: #b42318; }
        .toast[data-type="info"]    { background: #111;   }

        .toast__msg { flex: 1; line-height: 1.3; font-size: 14px }
        .toast__icon {
          width: 18px; height: 18px; display: inline-flex; align-items: center; justify-content: center;
          opacity: .9;
        }
        .toast__btn {
          background: transparent; border: 0; color: inherit; font-size: 16px; line-height: 1;
          cursor: pointer; opacity: .86; padding: 2px 4px; border-radius: 6px;
        }
        .toast__btn:hover { opacity: 1; background: rgba(255,255,255,.08) }
        .toast--leaving { animation: toast-out .12s ease-in forwards }
        /* light mode—keep high contrast */
        :root:not(.dark) .toast[data-type="info"] { background: #111; color: #fff }
      `}</style>

      <div className="toaster-host">
        {toasts.map((t) => (
          <ToastItem key={t.id} id={t.id} msg={t.msg} type={t.type} onClose={() => remove(t.id)} />
        ))}
      </div>
    </>,
    host
  )
}

function ToastItem({ id, msg, type = 'info', onClose }) {
  // Simple icons with Unicode—replace with SVGs if you prefer
  const icon = type === 'success' ? '✔' : type === 'error' ? '⚠' : 'ℹ'

  return (
    <div role="status" aria-live="polite" className="toast" data-type={type} data-id={id}>
      <span className="toast__icon" aria-hidden>{icon}</span>
      <div className="toast__msg">{msg}</div>
      <button className="toast__btn" aria-label="Dismiss" onClick={onClose}>×</button>
    </div>
  )
}
