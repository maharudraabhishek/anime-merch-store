import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ThemeContext } from './context/ThemeContext.jsx';
import { AuthContext } from './context/AuthContext.jsx';
import { useCart } from './context/CartContext.jsx'; // <-- import your hook

/**
 * Top navigation with theme toggle, auth actions, and cart badge.
 * Shows username and logout when authenticated.
 */
const Navbar = () => {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const { user, logout } = useContext(AuthContext);
  const { totalCount } = useCart(); // <-- read count from context
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <header className="bg-card text-foreground shadow-md">
      <nav className="container mx-auto flex items-center justify-between py-4">
        <Link to="/" className="text-xl font-heading text-primary">
          Anime<span className="text-secondary">Merch</span>
        </Link>

        <ul className="flex items-center space-x-4">
          <li>
            <Link to="/" className="hover:text-primary">Home</Link>
          </li>

          <li className="relative"> {/* <-- anchor for badge */}
            <Link to="/cart" className="hover:text-primary relative inline-block">
              Cart
              {totalCount > 0 && (
                <span
                  aria-label={`${totalCount} items in cart`}
                  className="absolute -right-3 -top-2 text-xs rounded-full px-2 py-[2px] bg-black text-white"
                >
                  {totalCount}
                </span>
              )}
            </Link>
          </li>

          <li>
            <button
              onClick={toggleTheme}
              className="p-2 rounded hover:bg-accent/10"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? '🌙' : '☀️'}
            </button>
          </li>

          {user ? (
            <>
              <li className="text-sm">Hi, {user.username}</li>
              <li>
                <button
                  onClick={handleLogout}
                  className="underline text-sm text-secondary"
                >
                  Logout
                </button>
              </li>
            </>
          ) : (
            <>
              <li>
                <Link to="/login" className="hover:text-primary text-sm">
                  Login
                </Link>
              </li>
              <li>
                <Link to="/register" className="hover:text-primary text-sm">
                  Register
                </Link>
              </li>
            </>
          )}
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;
