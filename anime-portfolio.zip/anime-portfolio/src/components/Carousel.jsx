import React from 'react'

const slides = [
  { id: 1, title: 'Attack on Titan Drop', src: 'https://animeape.com/wp-content/uploads/2025/08/Survey-Corps-Attack-on-Titan_Varsity-Jacket-3L_BACK-Mockup-400x400.jpg' },
  { id: 2, title: 'Demon Slayer Collection', src: 'https://shoppingnest.in/cdn/shop/files/9_3b62cd83-6a9c-4c01-986a-d546fc0fa575.jpg' },
  { id: 3, title: 'One Piece Hoodies', src: 'https://prestige-life.com/wp-content/uploads/2022/09/One-piece-Hoodie-Jacket-06.jpg' },
]

export default function Carousel() {
  return (
    <div className="rounded-lg overflow-hidden border">
      <div className="grid md:grid-cols-3 gap-0">
        {slides.map(s => (
          <div key={s.id} className="h-56 md:h-64 overflow-hidden">
            <img src={s.src} alt={s.title} className="w-full h-full object-cover" loading="lazy" />
          </div>
        ))}
      </div>
    </div>
  )
}