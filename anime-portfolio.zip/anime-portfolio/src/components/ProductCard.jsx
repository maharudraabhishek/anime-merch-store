import React from "react";
import { useCart } from "../context/CartContext.jsx";
import { useToast } from "../context/ToastContext.jsx";

export default function ProductCard({ product }) {
  const { getQty, increment, decrement } = useCart();
  const { notify } = useToast();

  const qty = getQty(product.id);
  const title = product.title ?? product.name ?? "Product";
  const price = Number(product.price ?? 0);

  const handlePlus = () => {
    const { firstAdd } = increment(product, 1);
    if (firstAdd) {
      notify(`Added “${title}” to cart`, { type: "success" });
    }
  };

  const handleMinus = () => decrement(product.id, 1);

  return (
    <div className="rounded-2xl border bg-card text-card-foreground p-4 shadow-sm">
      <div className="aspect-square w-full overflow-hidden rounded-xl mb-3">
        {product.image ? (
          <img
            src={product.image}
            alt={title}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="h-full w-full grid place-items-center text-sm text-muted-foreground">
            No image
          </div>
        )}
      </div>

      <div className="mb-2 font-medium truncate">{title}</div>

      <div className="mb-4 text-sm text-muted-foreground">
        ₹{price.toLocaleString("en-IN")}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleMinus}
            disabled={qty === 0}
            aria-label="Decrease quantity"
            className="h-9 w-9 rounded-md border px-2 text-lg disabled:opacity-50"
          >
            –
          </button>

          <span className="min-w-8 text-center tabular-nums select-none">{qty}</span>

          <button
            type="button"
            onClick={handlePlus}
            aria-label="Increase quantity"
            className="h-9 w-9 rounded-md border px-2 text-lg"
          >
            +
          </button>
        </div>

        {qty === 0 && (
          <button
            type="button"
            onClick={handlePlus}
            className="rounded-md border px-3 py-1.5 text-sm bg-secondary text-secondary-foreground hover:opacity-90"
          >
            Add
          </button>
        )}
      </div>
    </div>
  );
}
