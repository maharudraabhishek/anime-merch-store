import React from "react";
import { Button } from "./components/ui/button";
import { useToast } from "./components/ui/use-toast";
import { useCart } from "./contexts/CartContext";
import { useToast } from './context/ToastContext.jsx';



export default function ProductCard({ product }) {
  const { toast } = useToast();
  const { getQty, increment, decrement } = useCart();
  const qty = getQty(product.id);

  const { notify } = useToast()
  addToCart({ ...product, image: img }, 1)
  notify(`Added “${product.title}” to cart`, { type: 'success' })


  const handlePlus = () => {
    const { firstAdd } = increment(product, 1);
    if (firstAdd) {
      toast({
        title: "Added to cart",
        description: `${product.title ?? product.name ?? "Product"} has been added.`,
        duration: 2000,
      });
    }
  };

  const handleMinus = () => decrement(product.id, 1);

  return (
    <div className="rounded-2xl border bg-card text-card-foreground p-4 shadow-sm">
      <div className="aspect-square w-full overflow-hidden rounded-xl mb-3">
        {product.image ? (
          <img
            src={product.image}
            alt={product.title ?? product.name}
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="h-full w-full grid place-items-center text-sm text-muted-foreground">
            No image
          </div>
        )}
      </div>

      <div className="mb-2 font-medium truncate">
        {product.title ?? product.name}
      </div>

      <div className="mb-4 text-sm text-muted-foreground">
        ₹{Number(product.price ?? 0).toLocaleString("en-IN")}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            type="button"
            size="icon"
            variant="outline"
            onClick={handleMinus}
            disabled={qty === 0}
            aria-label="Decrease quantity"
          >
            –
          </Button>

          <span className="min-w-8 text-center tabular-nums select-none">{qty}</span>

          <Button
            type="button"
            size="icon"
            onClick={handlePlus}
            aria-label="Increase quantity"
          >
            +
          </Button>
        </div>

        {/* Optional: a separate “Add” button for 0->1, if you like */}
        {qty === 0 && (
          <Button type="button" onClick={handlePlus} variant="secondary">
            Add
          </Button>
        )}
      </div>
    </div>
  );
}
