import express from 'express';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import pkg from 'pg';

const { Pool } = pkg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ---- DB init ----
const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // set on Railway
  ssl: process.env.PGSSLMODE === 'disable' ? false : { rejectUnauthorized: false }
});

async function runMigrations() {
  const schema = `
  CREATE TABLE IF NOT EXISTS app_users (
    id SERIAL PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT,
    password_hash TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE TABLE IF NOT EXISTS orders (
    id BIGSERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
    total NUMERIC(12,2) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE TABLE IF NOT EXISTS order_items (
    id BIGSERIAL PRIMARY KEY,
    order_id BIGINT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    price NUMERIC(12,2) NOT NULL,
    qty INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id);
  `;
  await pool.query(schema);
}

// Helpers
async function getUserByUsername(username) {
  const r = await pool.query('SELECT * FROM app_users WHERE username = $1', [username]);
  return r.rows[0] || null;
}

async function createUser({ username, email, passwordHash }) {
  const r = await pool.query(
    `INSERT INTO app_users (username, email, password_hash)
     VALUES ($1, $2, $3)
     ON CONFLICT (username) DO UPDATE SET email = EXCLUDED.email
     RETURNING *`,
    [username, email ?? null, passwordHash ?? null]
  );
  return r.rows[0];
}

async function getOrCreateGuestUser() {
  // generate a short random suffix
  const suffix = crypto.randomBytes(3).toString('hex'); // e.g., "53a9f2"
  const username = `guest_${suffix}`;
  return await createUser({ username, email: null, passwordHash: null });
}

async function getOrdersForUser(username) {
  const user = await getUserByUsername(username);
  if (!user) return [];

  const orders = await pool.query(
    `SELECT id, total, created_at
     FROM orders
     WHERE user_id = $1
     ORDER BY created_at DESC`,
    [user.id]
  );

  const rows = orders.rows;
  const output = [];
  for (const o of rows) {
    const items = await pool.query(
      `SELECT product_id, title, price, qty FROM order_items WHERE order_id = $1`,
      [o.id]
    );
    output.push({
      id: Number(o.id),
      total: Number(o.total),
      createdAt: o.created_at,
      items: items.rows.map(it => ({
        id: Number(it.product_id),
        title: it.title,
        price: Number(it.price),
        qty: Number(it.qty)
      }))
    });
  }
  return output;
}

// ---- App setup ----
const app = express();
app.use(express.json());

// In‑memory store of products for demo purposes
let products = [


  {
    id: 1,
    title: 'Naruto T‑Shirt',
    price: 599,
    category: 'T‑Shirt',
    description: 'Soft cotton tee featuring Naruto Uzumaki.',
    image: 'https://fanatics.frgimages.com/naruto/youth-bioworld-black/orange-naruto-uzumaki-cosplay-t-shirt_pi5283000_altimages_ff_5283608-ac53a8318b6d6cf4da67alt1_full.jpg',
  },
  {
    id: 2,
    title: 'One Piece Hoodie',
    price: 899,
    category: 'Hoodie',
    description: 'Stay warm with Luffy and crew on this cosy hoodie.',
    image: 'https://prestige-life.com/wp-content/uploads/2022/09/One-piece-Hoodie-Jacket-06.jpg',
  },
  {
    id: 3,
    title: 'Attack on Titan Jacket',
    price: 1299,
    category: 'Jacket',
    description: 'Scout Regiment jacket inspired by Attack on Titan.',
    image: 'https://rukminim2.flixcart.com/image/480/640/xif0q/kid-costume-wear/3/9/u/120-15-16-years-akatsuki-cloak-costume-for-cosplay-naruto-original-imagq8d7vevz82pe.jpeg',
  },
  {
    id: 4,
    title: 'Demon Slayer Katana',
    price: 2999,
    category: 'Katana',
    description: 'Replica Nichirin blade from Demon Slayer.',
    image: 'https://shoppingnest.in/cdn/shop/files/9_3b62cd83-6a9c-4c01-986a-d546fc0fa575.jpg',
  },
  {
    id: 5,
    title: 'Dragon Ball Action Figure',
    price: 499,
    category: 'Figure',
    description: 'Collectible figure of Goku powering up.',
    image: 'https://offostore.com/cdn/shop/files/DBAF47_1.png',
  },
  {
    id: 6,
    title: 'My Hero Academia Jacket',
    price: 299,
    category: 'Poster',
    description: 'High quality poster featuring Deku and friends.',
    image: 'https://m.media-amazon.com/images/I/61NVD4XIhhL._AC_UY1100_.jpg',
  },
  {
    id: 7,
    title: 'Jujutsu Kaisen Jacket',
    price: 1499,
    category: 'Jacket',
    description: 'Sport the Tokyo Jujutsu High uniform.',
    image: 'https://rukminim2.flixcart.com/image/480/640/xif0q/t-shirt/l/b/5/s-tshirt-half-purple-ora-ora-s-comicsense-original-imah5ggr6pw2hwgr.jpeg',
  },
  {
    id: 8,
    title: 'Bleach Hoodie',
    price: 799,
    category: 'Coat',
    description: 'Bankai‑inspired coat from Bleach.',
    image: 'https://images-cdn.ubuy.com.pk/66194f5f32f0ba57e7045270-bleach-kurosaki-ichigo-robe-cloak-coat.jpg',
  },
];

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/products', (_req, res) => res.json(products));
app.get('/api/products/:id', (req, res) => {
  const p = products.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

// Register: create user in DB
app.post('/api/register', async (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) return res.status(400).json({ error: 'Missing fields' });

  const existing = await getUserByUsername(username);
  if (existing) return res.status(400).json({ error: 'User exists' });

  const passwordHash = await bcrypt.hash(password, 8);
  const user = await createUser({ username, email, passwordHash });
  res.json({ user: { id: user.id, username: user.username, email: user.email } });
});

// Login: validate from DB
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
  const user = await getUserByUsername(username);
  if (!user || !user.password_hash) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ user: { id: user.id, username: user.username, email: user.email } });
});

// Get orders by username (logged-in OR guest kept in localStorage)
app.get('/api/orders', async (req, res) => {
  const username = (req.query.username || '').trim();
  if (!username) return res.json([]);
  const orders = await getOrdersForUser(username);
  res.json(orders);
});

// Create order: link to user if provided; else create a random guest user and return it
app.post('/api/orders', async (req, res) => {
  const { items, total, username } = req.body || {};
  if (!Array.isArray(items) || typeof total !== 'number') {
    return res.status(400).json({ error: 'Invalid payload' });
  }

  let user = null;
  if (username) {
    user = await getUserByUsername(username);
    if (!user) {
      // auto-create if client sent a new username (rare but ok)
      user = await createUser({ username, email: null, passwordHash: null });
    }
  } else {
    user = await getOrCreateGuestUser();
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const ord = await client.query(
      `INSERT INTO orders (user_id, total) VALUES ($1, $2) RETURNING id, created_at`,
      [user.id, total]
    );
    const orderId = ord.rows[0].id;

    const insertValues = [];
    const params = [];
    let p = 1;
    for (const it of items) {
      params.push(orderId, it.id, it.title, it.price, it.qty);
      insertValues.push(`($${p}, $${p+1}, $${p+2}, $${p+3}, $${p+4})`);
      p += 5;
    }
    if (insertValues.length) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, title, price, qty) VALUES ${insertValues.join(',')}`,
        params
      );
    }

    await client.query('COMMIT');
    res.json({
      ok: true,
      order: {
        id: Number(orderId),
        createdAt: ord.rows[0].created_at,
        total,
        items
      },
      user: { username: user.username } // <-- return (guest or real) username to store locally
    });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).json({ error: 'Failed to create order' });
  } finally {
    client.release();
  }
});

// Serve static
const distDir = path.join(__dirname, '..', 'dist');
const publicDir = path.join(__dirname, '..', 'public');
app.use('/assets', express.static(path.join(publicDir, 'assets')));
app.use(express.static(distDir));
app.get('*', (_req, res) => res.sendFile(path.join(distDir, 'index.html')));

const PORT = process.env.PORT || 8080;

runMigrations()
  .then(() => app.listen(PORT, () => console.log(`[server] listening on :${PORT}`)))
  .catch((e) => {
    console.error('Migration failed', e);
    process.exit(1);
  });
