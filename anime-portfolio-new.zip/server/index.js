import express from 'express';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

let users = [];   // { id, username, email, passwordHash }
let orders = [];  // { id, items, total, createdAt, username }

const products = [
  { id: 1, title: "Attack on Titan Jacket", price: 2999, description: "Survey Corps inspired jacket with embroidered insignia." },
  { id: 2, title: "Naruto T-Shirt", price: 899, description: "Uzumaki swirl tee – soft cotton." },
  { id: 3, title: "Demon Slayer Katana", price: 1999, description: "Replica nichirin sword (display prop)." },
  { id: 4, title: "One Piece Luffy Hoodie", price: 1899, description: "Straw Hat crew comfy hoodie." },
  { id: 5, title: "Jujutsu Kaisen T-Shirt", price: 999, description: "Cursed energy graphic tee." },
  { id: 6, title: "Tokyo Ghoul Mask Tee", price: 1099, description: "Ken Kaneki mask tee." },
  { id: 7, title: "Bleach Captain Coat", price: 3499, description: "Gotei 13 captain-style coat." },
  { id: 8, title: "My Hero Academia Jacket", price: 2599, description: "UA High varsity jacket." }
];

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.get('/api/products', (_req, res) => res.json(products));

app.get('/api/products/:id', (req, res) => {
  const p = products.find(x => x.id === Number(req.params.id));
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

app.post('/api/register', async (req, res) => {
  const { username, email, password } = req.body || {};
  if (!username || !email || !password) return res.status(400).json({ error: 'Missing fields' });
  if (users.some(u => u.username === username || u.email === email)) return res.status(400).json({ error: 'User exists' });
  const passwordHash = await bcrypt.hash(password, 8);
  const user = { id: Date.now(), username, email, passwordHash };
  users.push(user);
  res.json({ user: { id: user.id, username, email } });
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });
  const user = users.find(u => u.username === username);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  res.json({ user: { id: user.id, username: user.username, email: user.email } });
});

app.get('/api/orders', (_req, res) => res.json(orders.slice().reverse()));

app.post('/api/orders', (req, res) => {
  const { items, total, username } = req.body || {};
  if (!Array.isArray(items) || typeof total !== 'number') return res.status(400).json({ error: 'Invalid payload' });
  const order = { id: Date.now(), items, total, username: username || 'guest', createdAt: new Date().toISOString() };
  orders.push(order);
  res.json({ ok: true, order });
});

const distDir = path.join(__dirname, '..', 'dist');
app.use(express.static(distDir));
app.get('*', (_req, res) => res.sendFile(path.join(distDir, 'index.html')));

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`[server] listening on :${PORT}`));