import React, { createContext, useState } from 'react';

/**
 * AuthContext stores the current authenticated user and exposes helper
 * functions to log in and log out.  In a real project you would
 * integrate with your backend's authentication API, store tokens
 * securely and protect private routes.  Here we simply keep a user
 * object in memory to demonstrate how context can be used to manage
 * auth state.
 */
export const AuthContext = createContext({
  user: null,
  login: () => {},
  logout: () => {},
});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);

  const login = async (credentials) => {
    // TODO: call your backend API to authenticate the user
    // For demonstration we accept any username/password and set a
    // simple user object.
    setUser({ username: credentials.username });
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};