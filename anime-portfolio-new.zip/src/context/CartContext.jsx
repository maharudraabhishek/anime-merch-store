import React, { createContext, useState, useMemo } from 'react';

/**
 * CartContext provides a simple state container for shopping cart
 * functionality.  It stores an array of cart items with quantity
 * counts, exposes helper functions to add and remove items, and
 * computes the total price.  You could persist this to localStorage
 * or a backend service in a real application.
 */
export const CartContext = createContext({
  cart: [],
  addToCart: () => {},
  removeFromCart: () => {},
  clearCart: () => {},
  total: 0,
});

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  /**
   * Add a product to the cart.  If the product is already in the
   * cart, increment its quantity; otherwise, add it with quantity 1.
   */
  const addToCart = (product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { ...product, quantity }];
    });
  };

  /**
   * Remove a product from the cart entirely.  You could also
   * decrement quantity instead.
   */
  const removeFromCart = (id) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  /**
   * Clear the cart.
   */
  const clearCart = () => setCart([]);

  /**
   * Compute the total cost of the cart.  useMemo caches the value
   * until the cart changes.
   */
  const total = useMemo(
    () => cart.reduce((sum, item) => sum + item.price * item.quantity, 0),
    [cart]
  );

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, clearCart, total }}>
      {children}
    </CartContext.Provider>
  );
};
