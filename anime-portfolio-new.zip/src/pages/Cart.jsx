import React from 'react';

/**
 * Shopping cart page.  In a complete implementation this page would
 * display the contents of the user's cart, allow them to adjust
 * quantities and remove items, and proceed to checkout.  For this
 * portfolio demo we present a placeholder.
 */
const Cart = () => {
  return (
    <div className="max-w-2xl mx-auto mt-8 text-center">
      <h2 className="text-2xl font-semibold mb-4">Your Cart</h2>
      <p>The cart functionality is coming soon.</p>
    </div>
  );
};

export default Cart;