import React from 'react';

/**
 * Checkout page.  This would normally collect shipping and payment
 * details and submit an order to the backend.  For demonstration
 * purposes we display a simple thank you message.
 */
const Checkout = () => {
  return (
    <div className="max-w-xl mx-auto mt-8 text-center">
      <h2 className="text-2xl font-semibold mb-4">Checkout</h2>
      <p>Checkout functionality will be added in the future.</p>
    </div>
  );
};

export default Checkout;