import React, { useContext, useState } from 'react'
import { AuthContext } from '../context/AuthContext.jsx'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const { login } = useContext(AuthContext)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setErr('')
    try {
      await login({ username, password })
      navigate('/')
    } catch (e) {
      setErr(e?.response?.data?.error || 'Login failed')
    }
  }

  return (
    <form onSubmit={onSubmit} className="max-w-sm space-y-3">
      <h1 className="text-2xl font-semibold">Login</h1>
      {err && <div className="text-red-600 text-sm">{err}</div>}
      <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" className="border rounded px-3 py-2 w-full"/>
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="border rounded px-3 py-2 w-full"/>
      <button className="rounded px-4 py-2 bg-black text-white">Login</button>
    </form>
  )
}