import React from 'react'

const slides = [
  { id: 1, title: 'Attack on Titan Drop', src: 'https://i.pinimg.com/736x/8a/2a/1d/8a2a1dc2a6ebf1b93e9a90c7a54e78e5.jpg' },
  { id: 2, title: 'Demon Slayer Collection', src: 'https://i.pinimg.com/736x/44/d5/18/44d5181f9f59c5cdb5d43b92b68a4f41.jpg' },
  { id: 3, title: 'One Piece Hoodies', src: 'https://i.pinimg.com/736x/4a/a6/58/4aa658e77a77c9f2b869c226a3d7c1f9.jpg' }
]

export default function Carousel() {
  return (
    <div className="rounded-lg overflow-hidden border">
      <div className="grid md:grid-cols-3 gap-0">
        {slides.map(s => (
          <div key={s.id} className="h-56 md:h-64 overflow-hidden">
            <img src={s.src} alt={s.title} className="w-full h-full object-cover" loading="lazy" />
          </div>
        ))}
      </div>
    </div>
  )
}