import React from 'react';
import { Link } from 'react-router-dom';

/**
 * A reusable card component to display product information.  It shows the
 * product image, title and price, and links to the product details
 * page.  In a real application you would also display ratings,
 * categories and provide an add‑to‑cart button.
 */
const ProductCard = ({ product }) => {
  return (
    <div className="bg-card rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <Link to={`/product/${product.id}`} className="block">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-56 object-cover object-center"
        />
        <div className="p-4">
          <h3 className="text-lg font-semibold mb-2 truncate" title={product.title}>
            {product.title}
          </h3>
          <p className="text-secondary font-bold">₹{product.price.toFixed(2)}</p>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;