import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext.jsx';

/**
 * A reusable card component to display product information.  It shows the
 * product image, title and price, and links to the product details
 * page.  It also includes an add‑to‑cart button that interacts with
 * the CartContext.  In a real application you might also display
 * ratings or categories.
 */
const ProductCard = ({ product }) => {
  const { addToCart } = useContext(CartContext);
  return (
    <div className="bg-card rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow flex flex-col">
      {/* Wrap image in link for product details */}
      <Link to={`/product/${product.id}`} className="block">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-56 object-cover object-center"
        />
      </Link>
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <h3 className="text-lg font-semibold mb-2 truncate" title={product.title}>
            {product.title}
          </h3>
          <p className="text-secondary font-bold">₹{product.price.toFixed(2)}</p>
        </div>
        <button
          onClick={() => addToCart(product, 1)}
          className="mt-4 bg-primary text-white py-2 px-3 rounded hover:bg-primary/80 w-full"
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
