import axios from 'axios'
const api = axios.create({ baseURL: '' }) // same origin

export const fetchProducts = async () => (await api.get('/api/products')).data
export const fetchProduct = async (id) => (await api.get(`/api/products/${id}`)).data
export const registerUser = async (payload) => (await api.post('/api/register', payload)).data
export const loginUser = async (payload) => (await api.post('/api/login', payload)).data
export const createOrder = async (payload) => (await api.post('/api/orders', payload)).data
export const fetchOrders = async () => (await api.get('/api/orders')).data