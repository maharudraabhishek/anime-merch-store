import React, { createContext, useEffect, useState } from 'react'

export const ThemeContext = createContext({ dark: false, setDark: () => {} })

export function ThemeProvider({ children }) {
  const [dark, setDark] = useState(false)
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
  }, [dark])
  return <ThemeContext.Provider value={{ dark, setDark }}>{children}</ThemeContext.Provider>
}