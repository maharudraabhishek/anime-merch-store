import React, { useContext, useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { fetchProduct } from '../api/index.js'
import { CartContext } from '../context/CartContext.jsx'
import { getPinImage } from '../lib/pinImages.js'

export default function ProductDetails() {
  const { id } = useParams()
  const { addToCart } = useContext(CartContext)
  const [product, setProduct] = useState(null)

  useEffect(() => { fetchProduct(id).then(setProduct).catch(console.error) }, [id])

  if (!product) return <div>Loading...</div>
  const img = getPinImage(product.title)

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <img src={img} alt={product.title} className="w-full h-auto rounded-lg" />
      <div>
        <h1 className="text-2xl font-semibold mb-2">{product.title}</h1>
        <p className="opacity-80 mb-4">{product.description}</p>
        <div className="text-xl font-medium mb-4">₹{product.price}</div>
        <button onClick={() => addToCart(product, 1)} className="rounded-md px-4 py-2 bg-black text-white hover:opacity-90">
          Add to cart
        </button>
      </div>
    </div>
  )
}