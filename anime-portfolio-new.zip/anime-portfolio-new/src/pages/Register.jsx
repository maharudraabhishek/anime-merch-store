import React, { useState } from 'react'
import { registerUser } from '../api/index.js'
import { useNavigate } from 'react-router-dom'

export default function Register() {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  const navigate = useNavigate()

  const onSubmit = async (e) => {
    e.preventDefault()
    setErr('')
    try {
      await registerUser({ username, email, password })
      navigate('/login')
    } catch (e) {
      setErr(e?.response?.data?.error || 'Register failed')
    }
  }

  return (
    <form onSubmit={onSubmit} className="max-w-sm space-y-3">
      <h1 className="text-2xl font-semibold">Register</h1>
      {err && <div className="text-red-600 text-sm">{err}</div>}
      <input value={username} onChange={e=>setUsername(e.target.value)} placeholder="Username" className="border rounded px-3 py-2 w-full"/>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="border rounded px-3 py-2 w-full"/>
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="border rounded px-3 py-2 w-full"/>
      <button className="rounded px-4 py-2 bg-black text-white">Create account</button>
    </form>
  )
}